Spanish-accents
Provided free by https://languageloftroatan.com/
Code by https://github.com/ItsChasman/spanish-accents/tree/main

Really simple AHK program to give you diacritical marks for use in Spanish language typing.  

Run the program by double-clicking it or follow the instructions to put it in the startup folder.

Using a similar method to the way you type them when you switch keyboards. Preceding the letter by a special character gives you the mark you need.

 í ó ú é ñ are formed by typing the ' mark directly proceeding the letter.
e.g.    '+n produce ñ

ü is produced by typing / before the u so /+u equal s ü

The ¡ and ¿ are produced by simply pressing the windows key at the same time as the other keys so pressing the keys windows+shift+/ produce ¿ and similarly producing ¡ is created by pressing windows+shift+1  ¡

To make sure the program is always running on Windows follow the instructions below and add it to the Windows start up folder.

Instructions

Select the Start button and scroll to find the app you want to run at startup.

Press the Windows logo key + R, type shell:startup, then select OK. This opens the Startup folder.

Locate where you have stored accents.exe. Create a shortcut by right-clicking on it and selecting "create shortcut."
Move the shortcut into the  Startup folder.

It will then start up every time windows starts and can be seen as a green H in the icons in the taskbar.